import socket
import os
import sys
import ssl
from collections import OrderedDict, deque
from multiprocessing import Process

DEFAULT_PROXY_HOST = '127.0.0.1'
DEFAULT_PROXY_PORT = 8888
BUFFER_SIZE = 4096
CACHE_SIZE = 100

# Load blocked URLs from blocklist.txt
BLOCKED_URLS = set()
with open("blockSites.txt", "r") as blocklist_file:
    for line in blocklist_file:
        BLOCKED_URLS.add(line.strip())

# Caches to store popular content using LRU and FIFO algorithms
LRU_CACHE = OrderedDict()
FIFO_CACHE = deque(maxlen=CACHE_SIZE)

def handle_client(client_socket):
    try:
        request = client_socket.recv(BUFFER_SIZE).decode()
        if not request:
            return

        if not request.startswith("GET"):
            print("Unsupported request method")
            client_socket.send("HTTP/1.1 501 Not Implemented\r\n\r\n".encode())
            return

        url = request.split(" ")[1]
        print(f"Received request: {request}")
        print(f"Requested URL: {url}")

        if any(blocked_url in url for blocked_url in BLOCKED_URLS):
            print("Blocking request to a blocked URL")
            client_socket.send(b"HTTP/1.1 403 Forbidden\r\n\r\n website blocked \nerror 403")
            return

        if url in LRU_CACHE:
            print("LRU Cache hit!")
            client_socket.send(LRU_CACHE[url])
            return

        if url in FIFO_CACHE:
            print("FIFO Cache hit!")
            client_socket.send(FIFO_CACHE[url])
            return

        target_host, target_port = get_target_host_and_port(url)
        target_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        target_socket.connect((target_host, target_port))

        if target_port == 443:  # HTTPS
            context = ssl.create_default_context()
            target_socket = context.wrap_socket(target_socket, server_hostname=target_host)

        target_socket.send(request.encode())

        response = b""
        while True:
            data = target_socket.recv(BUFFER_SIZE)
            if not data:
                break
            response += data
            client_socket.send(data)

        # Update the LRU cache
        if len(LRU_CACHE) >= CACHE_SIZE:
            removed_item = LRU_CACHE.popitem(last=False)
            print(f"LRU Cache removed: {removed_item}")
        LRU_CACHE[url] = response
        print("LRU Cache updated")

        # Update the FIFO cache
        if url not in FIFO_CACHE:
            FIFO_CACHE.append(url)
            print("FIFO Cache added")
        print("FIFO Cache updated")

    except Exception as e:
        print(f"Error: {e}")

    finally:
        client_socket.close()

def get_target_host_and_port(url):
    parts = url.split('/')
    host_port = parts[2].split(':')
    target_host = host_port[0]
    target_port = 80

    if len(host_port) == 2:
        target_port = int(host_port[1])

    return target_host, target_port

def main():
    if len(sys.argv) == 3:
        proxy_host = sys.argv[1]
        proxy_port = int(sys.argv[2])
    else:
        proxy_host = DEFAULT_PROXY_HOST
        proxy_port = DEFAULT_PROXY_PORT

    proxy_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    proxy_socket.bind((proxy_host, proxy_port))
    proxy_socket.listen(5)

    print(f"Initializing Socket..")
    print(f"Socket Binding..")
    print(f"Proxy server is listening on {proxy_host}:{proxy_port}")

    while True:
        client_socket, addr = proxy_socket.accept()
        print(f"Accepted connection from {addr[0]}:{addr[1]}")

        # Use multiprocessing to handle each client request
        process = Process(target=handle_client, args=(client_socket,))
        process.start()
        process.join()  # Wait for the process to finish (optional)

if __name__ == "__main__":
    main()
